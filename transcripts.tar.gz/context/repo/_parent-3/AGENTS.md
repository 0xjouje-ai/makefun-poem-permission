# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## Conventions learned
- The `skills` CLI (`npx skills@latest`) installs into `~/.agents/skills/`, which Muse's skill catalog does NOT scan. For Muse to discover an installed skill, symlink its folder into `~/workspace/custom-skills/` (same pattern as binance-agentic-wallet). Verify afterwards with `muse.skill_search`.
- **Blade files: NEVER write Blade syntax inside JS/CSS comments or strings in a `.blade.php` file** — Blade compiles `@directive`, `{{ }}`, and `{!! !!}` anywhere, including inside `//` comments. Twice (2026-11-17) this crashed pelindo-kp's absen page: `{!! json_encode() !!}` in a comment called json_encode() with 0 args; `@json` in a comment became `json_encode(otomatis di-escape)`. Before committing ANY `.blade.php` change, grep for it: `grep -rn "//.*@\|/\*.*@\|{!!" resources/views/` and `grep -rn "json_encode\|@json" resources/views/` — every hit inside a comment/string must be reworded.
- **Laravel 9 `@json` cannot take an inline array literal** (verified against framework v9.52.23 source, `CompilesJson::compileJson` does `explode(',', ...)` — it cuts the array at the first comma, producing `json_encode([ 'lat' => ...` with an unclosed `[` → ParseError "Unclosed '[' on line 140"). Always pass a variable prepared in the controller (`@json($officeData)`), never `@json([...])`.
